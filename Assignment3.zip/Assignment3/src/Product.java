public class Product {
    String id;
    String name;
    int price;
    String type;
    String code;
    int stock;

    Product(String id, String name, int price, String type, String code, int stock){
        this.id = id;
        this.name = name;
        this.price = price;
        this.type = type;
        this.code = code;
        this.stock = stock;
    }

    String toRecord(){
        return "PRODUCT|" + id + "|" + name + "|" + price + "|" + type + "|" + code + "|" + stock;
    }
}
