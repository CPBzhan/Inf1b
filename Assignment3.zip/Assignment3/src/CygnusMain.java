import java.util.*;

public class CygnusMain {
    static String storeName = "";
    static int balance = 0;
    static TreeMap<String, Product> products = new TreeMap<>();
    static ArrayList<Order> orders = new ArrayList<>();
    static StoreRules rules;
    static HashSet<String> orderIds = new HashSet<>();
    static boolean sawStore = false;
    static boolean inInventory = false;
    static boolean inventoryClosed = false;

    public static void main(String[] args) {
        try {
            resetState();
            readInput();
            printOutputSkeleton();
        } catch (Exception e) {
            System.out.println("ERROR");
        }
    }

    static void resetState() {
        storeName = "";
        balance = 0;
        products = new TreeMap<>();
        orders = new ArrayList<>();
        rules = null;
        orderIds = new HashSet<>();
        sawStore = false;
        inInventory = false;
        inventoryClosed = false;
    }


    static void requireFields(String[] parts, int need) {
        if (parts.length < need) {
            throw new RuntimeException("Too few fields");
        }
    }

    static String field(String[] parts, int i) {
        requireFields(parts, i + 1);
        return parts[i];
    }

    // Checks whether all requested items are available in the current inventory.
    static boolean isOrderAccepted(Order order) {
        int totalUnits = 0;
        for (int q : order.items.values()) {
            totalUnits += q;
        }

        if (storeName.equals("WordWorld")) {
            if (order.items.size() > 6) return false;
            if (totalUnits > 7) return false;
        }

        if (storeName.equals("PawPantry")) {
            if (order.items.size() > 2) return false;
            if (totalUnits > 7) return false;
        }

        if (storeName.equals("GreenGrocer")) {
            if (order.items.size() > 6) return false;

            boolean hasProduce = false;
            boolean hasDairy = false;

            for (String productId : order.items.keySet()) {
                Product product = products.get(productId);

                if (product.type.equals("produce")) hasProduce = true;
                if (product.type.equals("dairy")) hasDairy = true;
            }

            if (hasProduce && hasDairy) return false;
        }

        for (var item : order.items.entrySet()) {
            String productId = item.getKey();
            int requestedQuantity = item.getValue();

            Product product = products.get(productId);

            if (product == null) {
                return false;
            }

            if (requestedQuantity > product.stock) {
                return false;
            }
        }

        return true;
    }

    // Applies an accepted order to the current inventory and store balance.
    static void applyAcceptedOrder(Order order, int price) {
        for (var item : order.items.entrySet()) {
            String productId = item.getKey();
            int quantity = item.getValue();

            Product product = products.get(productId);
            product.stock -= quantity;
        }

        balance += price;
    }

    // Checks the assignment identifier format.
    static boolean isIdentifier(String s) {
        return s.matches("[a-zA-Z_][a-zA-Z0-9_]*");
    }

    // Checks that product ids start with an uppercase letter.
    static boolean isProductId(String s) {
        return s.matches("[A-Z][a-zA-Z0-9_]*");
    }

    // Reads all non-empty, non-comment records from standard input.
    static void readInput() {
        Scanner sc = new Scanner(System.in);
        Order currentOrder = null;

        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();

            if (line.startsWith("#")) {
                continue;
            }

            int commentIndex = line.indexOf("#");
            if (commentIndex != -1) {
                line = line.substring(0, commentIndex).trim();
            }

            if (line.isEmpty()) {
                continue;
            }

            String[] parts = line.split("\\|", -1);
            String tag = field(parts, 0);

            switch (tag) {
                case "STORE":
                    requireFields(parts, 2);
                    if (sawStore) {
                        throw new RuntimeException("Multiple STORE records");
                    }

                    sawStore = true;
                    storeName = field(parts, 1);

                    if (storeName.equals("WordWorld")) {
                        rules = new BookStoreRules();
                    } else if (storeName.equals("PawPantry")) {
                        rules = new PetStoreRules();
                    } else if (storeName.equals("GreenGrocer")) {
                        rules = new SupermarketRules();
                    } else {
                        throw new RuntimeException("Unknown store");
                    }

                    break;

                case "INVENTORY":
                    requireFields(parts, 2);
                    if (!sawStore) throw new RuntimeException("INVENTORY before STORE");
                    if (inInventory || inventoryClosed) throw new RuntimeException("Invalid inventory block");

                    balance = Integer.parseInt(field(parts, 1));
                    inInventory = true;
                    break;

                case "PRODUCT": {
                    requireFields(parts, 7);
                    if (rules == null) {
                        throw new RuntimeException("STORE must be defined before PRODUCT");
                    }

                    if (!inInventory) {
                        throw new RuntimeException("PRODUCT outside inventory");
                    }

                    String id = field(parts, 1);
                    String name = field(parts, 2);
                    int price = Integer.parseInt(field(parts, 3));
                    String type = field(parts, 4);
                    String code = field(parts, 5);
                    int stock = Integer.parseInt(field(parts, 6));

                    if (price <= 0 || stock < 0) {
                        throw new RuntimeException("Invalid product price or stock");
                    }

                    if (!isProductId(id)) {
                        throw new RuntimeException("Bad product id: " + id);
                    }
                    if (!isIdentifier(name)) {
                        throw new RuntimeException("Bad product name: " + name);
                    }
                    if (!isIdentifier(type)) {
                        throw new RuntimeException("Bad product type format: " + type);
                    }

                    if (products.containsKey(id)) {
                        throw new RuntimeException("Duplicate product id: " + id);
                    }

                    if (!rules.isValidProductType(type)) {
                        throw new RuntimeException("Invalid product type: " + type);
                    }
                    if (!rules.isValidPromotionCode(code)) {
                        throw new RuntimeException("Invalid promotion code: [" + code + "]");
                    }

                    products.put(id, new Product(id, name, price, type, code, stock));
                    break;
                }

                case "ORDER":
                    requireFields(parts, 2);
                    if (!inventoryClosed) {
                        throw new RuntimeException("ORDER before ENDINVENTORY");
                    }

                    if (currentOrder != null) {
                        throw new RuntimeException("Nested ORDER");
                    }

                    int parsedOrderId = Integer.parseInt(field(parts, 1));

                    if (parsedOrderId <= 0) {
                        throw new RuntimeException("Invalid order id");
                    }

                    String orderId = String.valueOf(parsedOrderId);

                    if (orderIds.contains(orderId)) {
                        throw new RuntimeException("Duplicate order id");
                    }

                    orderIds.add(orderId);
                    currentOrder = new Order(orderId);
                    orders.add(currentOrder);
                    break;

                case "ITEM":
                    requireFields(parts, 3);
                    if (currentOrder == null) {
                        throw new RuntimeException("ITEM outside ORDER");
                    }

                    String productId = field(parts, 1);
                    int quantity = Integer.parseInt(field(parts, 2));

                    if (!products.containsKey(productId)) {
                        throw new RuntimeException("Unknown product in order");
                    }

                    if (quantity <= 0) {
                        throw new RuntimeException("Invalid item quantity");
                    }

                    currentOrder.addItem(productId, quantity);
                    break;

                case "DISCOUNT":
                    requireFields(parts, 2);
                    if (currentOrder == null) {
                        throw new RuntimeException("DISCOUNT outside ORDER");
                    }

                    if (rules == null) {
                        throw new RuntimeException("STORE must be defined before DISCOUNT");
                    }

                    String discount = field(parts, 1);

                    if (!rules.isValidDiscountCode(discount)) {
                        throw new RuntimeException("Invalid discount");
                    }

                    currentOrder.discounts.add(discount);
                    break;

                case "ENDINVENTORY":
                    if (!inInventory) throw new RuntimeException("ENDINVENTORY outside inventory");
                    inInventory = false;
                    inventoryClosed = true;
                    break;

                case "ENDORDER":
                    if (currentOrder == null) {
                        throw new RuntimeException("ENDORDER outside ORDER");
                    }

                    if (currentOrder.items.isEmpty()) {
                        throw new RuntimeException("Order has no items");
                    }

                    currentOrder = null;
                    break;

                default:
                    throw new RuntimeException("Unknown record type");
            }
        }
        if (!sawStore) {
            throw new RuntimeException("Missing STORE");
        }

        if (inInventory) {
            throw new RuntimeException("Unclosed inventory");
        }

        if (!inventoryClosed) {
            throw new RuntimeException("Missing inventory");
        }

        if (currentOrder != null) {
            throw new RuntimeException("Unclosed order");
        }
    }

    // Prints all processed orders followed by the final inventory.
    static void printOutputSkeleton() {
        System.out.println("STORE|" + storeName);
        System.out.println();

        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);

            boolean accepted = isOrderAccepted(order);
            String status = accepted ? "accepted" : "rejected";

            PricingResult pricing = rules.price(order, products);

            System.out.println("ORDER|" + order.id + "|" + status + "|" + pricing.price);

            for (var item : order.items.entrySet()) {
                System.out.println("ITEM|" + item.getKey() + "|" + item.getValue());
            }

            if (!pricing.discount.isEmpty()) {
                System.out.println("DISCOUNT|" + pricing.discount);
            }

            System.out.println("ENDORDER");
            System.out.println();

            if (accepted) {
                applyAcceptedOrder(order, pricing.price);
            }
        }

        System.out.println("INVENTORY|" + balance);

        for (Product product : products.values()) {
            System.out.println(product.toRecord());
        }

        System.out.println("ENDINVENTORY");
    }
}