import java.util.*;

public class BookStoreRules implements StoreRules {
    private static final Set<String> TYPES =
            Set.of("book", "children", "stationery", "game");

    private static final Set<String> DISCOUNTS =
            Set.of("UNI", "HEALTH", "PROMO", "EMPLOYEE");

    public boolean isValidProductType(String type) {
        return TYPES.contains(type);
    }

    public boolean isValidPromotionCode(String code) {
        if (code.equals("_")) return true;
        if (code.isEmpty()) return false;
        return code.matches("c?f?h?r?t?");
    }

    public boolean isValidDiscountCode(String discount) {
        return DISCOUNTS.contains(discount);
    }

    // Returns the percentage discount for bookstore customer discount codes.
    public int discountPercent(String discount) {
        if (discount.equals("UNI")) return 10;
        if (discount.equals("HEALTH")) return 20;
        if (discount.equals("PROMO")) return 7;
        if (discount.equals("EMPLOYEE")) return 24;
        return 0;
    }

    private int discountCheapestFree(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly,
            String code,
            int requiredCount,
            String requiredType
    ) {
        int count = 0;
        int cheapest = Integer.MAX_VALUE;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains(code)) continue;
            if (requiredType != null && !product.type.equals(requiredType)) continue;

            count += item.getValue();
            cheapest = Math.min(cheapest, product.price);
        }

        return count >= requiredCount ? cheapest : 0;
    }

    private int discountPercentOnCode(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly,
            String code,
            int requiredCount,
            int percent,
            String requiredType
    ) {
        int count = 0;
        int discount = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());
            int quantity = item.getValue();

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains(code)) continue;
            if (requiredType != null && !product.type.equals(requiredType)) continue;

            count += quantity;
            discount += ((product.price * percent + 99) / 100) * quantity;
        }

        return count >= requiredCount ? discount : 0;
    }

    public int promotionalDiscount(Order order, TreeMap<String, Product> products, boolean restrictedOnly) {
        int discountC = discountCheapestFree(order, products, restrictedOnly, "c", 3, null);
        if (discountC > 0) return discountC;

        int discountF = discountPercentOnCode(order, products, restrictedOnly, "f", 2, 18, null);
        if (discountF > 0) return discountF;

        // h is unused.

        int discountT = discountPercentOnCode(order, products, restrictedOnly, "t", 1, 6, "book");
        if (discountT > 0) return discountT;

        return 0;
    }

    // Computes the best available price for this bookstore order.
    public PricingResult price(Order order, TreeMap<String, Product> products) {
        return PricingUtils.bestPrice(order, products, this);
    }


}