import java.util.*;

public class SupermarketRules implements StoreRules {
    private static final Set<String> TYPES =
            Set.of("produce", "dairy", "bakery", "alcohol");

    private static final Set<String> DISCOUNTS =
            Set.of("LOYALTY", "STAFF");

    public boolean isValidProductType(String type) {
        return TYPES.contains(type);
    }

    public boolean isValidPromotionCode(String code) {
        if (code.equals("_")) return true;
        if (code.isEmpty()) return false;
        return code.matches("a?j?m?y?");
    }

    public boolean isValidDiscountCode(String discount) { return DISCOUNTS.contains(discount); }

    public int discountPercent(String discount) {
        if (discount.equals("LOYALTY")) return 16;
        if (discount.equals("STAFF")) return 22;
        return 0;
    }

    private int discountCheapestFree(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly,
            String code,
            int requiredCount,
            String requiredType
    ) {
        int count = 0;
        int cheapest = Integer.MAX_VALUE;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains(code)) continue;
            if (requiredType != null && !product.type.equals(requiredType)) continue;

            count += item.getValue();
            cheapest = Math.min(cheapest, product.price);
        }

        return count >= requiredCount ? cheapest : 0;
    }

    private int discountPercentOnCode(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly,
            String code,
            int requiredCount,
            int percent,
            String requiredType
    ) {
        int count = 0;
        int discount = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());
            int quantity = item.getValue();

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains(code)) continue;
            if (requiredType != null && !product.type.equals(requiredType)) continue;

            count += quantity;
            discount += ((product.price * percent + 99) / 100) * quantity;
        }

        return count >= requiredCount ? discount : 0;
    }

    private int discountComboA(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly
    ) {
        boolean hasAlcohol = false;
        boolean hasDairy = false;
        boolean hasProduce = false;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains("a")) continue;

            if (product.type.equals("alcohol")) hasAlcohol = true;
            if (product.type.equals("dairy")) hasDairy = true;
            if (product.type.equals("produce")) hasProduce = true;
        }

        return (hasAlcohol && hasDairy && hasProduce) ? 3 : 0;
    }

    public int promotionalDiscount(Order order, TreeMap<String, Product> products, boolean restrictedOnly) {
        int discountA = discountComboA(order, products, restrictedOnly);
        if (discountA > 0) return discountA;

        int discountJ = discountPercentOnCode(order, products, restrictedOnly, "j", 3, 5, null);
        if (discountJ > 0) return discountJ;

        int discountM = discountPercentOnCode(order, products, restrictedOnly, "m", 1, 11, "bakery");
        if (discountM > 0) return discountM;

        int discountY = discountCheapestFree(order, products, restrictedOnly, "y", 3, null);
        if (discountY > 0) return discountY;

        return 0;
    }

    public PricingResult price(Order order, TreeMap<String, Product> products) {
        return PricingUtils.bestPrice(order, products, this);
    }
}