import java.util.*;

public interface StoreRules {
    boolean isValidProductType(String type);
    boolean isValidPromotionCode(String code);
    boolean isValidDiscountCode(String discount);

    int discountPercent(String discount);

    int promotionalDiscount(Order order, TreeMap<String, Product> products, boolean restrictedOnly);

    PricingResult price(Order order, TreeMap<String, Product> products);
}