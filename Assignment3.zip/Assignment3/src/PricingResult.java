public class PricingResult {
    int price;
    String discount;

    PricingResult(int price, String discount){
        this.price = price;
        this.discount = discount;
    }
}

