import java.util.*;

public class PetStoreRules implements StoreRules {
    private static final Set<String> TYPES =
            Set.of("food", "toy", "accessory", "grooming");

    private static final Set<String> DISCOUNTS =
            Set.of("LOYALTY", "VET");

    // Checks whether the product type is allowed for PawPantry.
    public boolean isValidProductType(String type) {
        return TYPES.contains(type);
    }

    // Checks PawPantry promotion codes.
    // A valid code is "" or a sorted non-repeating string using b, k, r, s, z.
    public boolean isValidPromotionCode(String code) {
        if (code.equals("_")) return true;
        if (code.isEmpty()) return false;
        return code.matches("b?k?r?s?z?");
    }

    // Checks whether the customer discount code is allowed for PawPantry.
    public boolean isValidDiscountCode(String discount) {
        return DISCOUNTS.contains(discount);
    }

    // Returns the customer discount percentage for PawPantry.
    public int discountPercent(String discount) {
        if (discount.equals("LOYALTY")) return 8;
        if (discount.equals("VET")) return 17;
        return 0;
    }

    private int discountCheapestFree(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly,
            String code,
            int requiredCount,
            String requiredType
    ) {
        int count = 0;
        int cheapest = Integer.MAX_VALUE;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains(code)) continue;
            if (requiredType != null && !product.type.equals(requiredType)) continue;

            count += item.getValue();
            cheapest = Math.min(cheapest, product.price);
        }

        return count >= requiredCount ? cheapest : 0;
    }

    private int discountPercentOnCode(
            Order order,
            TreeMap<String, Product> products,
            boolean restrictedOnly,
            String code,
            int requiredCount,
            int percent,
            String requiredType
    ) {
        int count = 0;
        int discount = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());
            int quantity = item.getValue();

            if (restrictedOnly && !product.code.contains("r")) continue;
            if (!product.code.contains(code)) continue;
            if (requiredType != null && !product.type.equals(requiredType)) continue;

            count += quantity;
            discount += ((product.price * percent + 99) / 100) * quantity;
        }

        return count >= requiredCount ? discount : 0;
    }


    // Calculates the total promotional discount for PawPantry.
    // Store-specific promotion details can be added here.
    // Applies the first applicable PawPantry promotional rule in code order.
    public int promotionalDiscount(Order order, TreeMap<String, Product> products, boolean restrictedOnly) {
        int discountB = discountPercentOnCode(order, products, restrictedOnly, "b", 2, 8, null);
        if (discountB > 0) return discountB;

        int discountK = discountPercentOnCode(order, products, restrictedOnly, "k", 1, 11, "toy");
        if (discountK > 0) return discountK;

        int discountS = discountCheapestFree(order, products, restrictedOnly, "s", 2, null);
        if (discountS > 0) return discountS;

        return 0;
    }

    // Computes the best price for a PawPantry order.
    public PricingResult price(Order order, TreeMap<String, Product> products) {
        return PricingUtils.bestPrice(order, products, this);
    }

}
