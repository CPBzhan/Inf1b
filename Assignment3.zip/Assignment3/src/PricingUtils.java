import java.util.*;

public class PricingUtils {
    // Calculates the total price without any discount or promotion.
    public static int basePrice(Order order, TreeMap<String, Product> products) {
        int total = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());
            total += product.price * item.getValue();
        }

        return total;
    }

    // Calculates the price after applying one customer discount code.
    // Products with promotion code 'r' are excluded from customer discounts.
    public static int customerDiscountPrice(
            Order order,
            TreeMap<String, Product> products,
            int percent
    ) {
        int total = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());
            int quantity = item.getValue();

            for (int i = 0; i < quantity; i++) {
                if (product.code.contains("r")) {
                    total += product.price;
                } else {
                    int discount = (product.price * percent + 99) / 100;
                    total += product.price - discount;
                }
            }
        }

        return Math.max(total, 0);
    }

    // Calculates the price of all items whose product code contains 'r'.
    public static int restrictedBasePrice(Order order, TreeMap<String, Product> products) {
        int total = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());

            if (product.code.contains("r")) {
                total += product.price * item.getValue();
            }
        }

        return total;
    }

    // Calculates the discounted price of all non-restricted items.
    public static int unrestrictedCustomerDiscountPrice(
            Order order,
            TreeMap<String, Product> products,
            int percent
    ) {
        int total = 0;

        for (var item : order.items.entrySet()) {
            Product product = products.get(item.getKey());
            int quantity = item.getValue();

            if (!product.code.contains("r")) {
                int discount = (product.price * percent + 99) / 100;
                total += (product.price - discount) * quantity;
            }
        }

        return Math.max(total, 0);
    }

    // Computes the best price using the general Cygnus 2.0 pricing algorithm.
    public static PricingResult bestPrice(
            Order order,
            TreeMap<String, Product> products,
            StoreRules rules
    ) {
        int base = basePrice(order, products);

        // Option B: apply promotional rules to the whole order.
        int allPromoPrice = Math.max(0, base - rules.promotionalDiscount(order, products, false));

        int bestSplitPrice = Integer.MAX_VALUE;
        String bestDiscount = "";

        for (String discount : order.discounts) {
            int percent = rules.discountPercent(discount);

            int unrestrictedPrice = unrestrictedCustomerDiscountPrice(order, products, percent);

            int restrictedPrice = restrictedBasePrice(order, products) - rules.promotionalDiscount(order, products, true);

            int candidate = Math.max(0, unrestrictedPrice + restrictedPrice);

            if (candidate < bestSplitPrice ||
                    (candidate == bestSplitPrice &&
                            (bestDiscount.isEmpty() || discount.compareTo(bestDiscount) < 0))) {
                bestSplitPrice = candidate;
                bestDiscount = discount;
            }
        }

        if (order.discounts.isEmpty()) {
            return new PricingResult(allPromoPrice, "");
        }

        if (bestSplitPrice < allPromoPrice) {
            return new PricingResult(bestSplitPrice, bestDiscount);
        }

        // If promotion-only ties with discount-based pricing, no DISCOUNT is printed.
        return new PricingResult(allPromoPrice, "");
    }
}