import java.util.TreeMap;
import java.util.TreeSet;

public class Order {
    String id;
    TreeMap<String, Integer> items = new TreeMap<>();
    TreeSet<String> discounts = new TreeSet<>();

    Order(String id){
        this.id = id;
    }

    void addItem(String productId, int quantity){
        items.put(productId, items.getOrDefault(productId, 0) + quantity);
    }
}
