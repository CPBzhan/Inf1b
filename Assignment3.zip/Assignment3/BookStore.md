# WordWorld

## Overview

WordWorld is a small bookstore. This document specifies the store‑specific
behaviour of the Cygnus program when the input begins with `STORE|WordWorld`.
The base input/output record format, normalisation rules, comment and
blank‑line handling, and general layout are defined in the Assignment 3
warmup documents (`ex01`–`ex05`) and are not repeated here.

## Store identification

The first non‑blank, non‑comment record must be `STORE|WordWorld`.

## Product catalog

Each `PRODUCT` record has fields `id|name|price|type|code|stock`.

* **id**: identifier starting with an uppercase letter; unique across the
  inventory.
* **price**: positive integer pounds per unit.
* **type**: one of `book`, `children`, `stationery`, `game`.
* **code**: either `_` (no promotions apply) or an identifier made up of
  the letters below, in alphabetical order without repetition:
  * `c` — eligible for the 3‑for‑2 promotion.
  * `r` — restricted from customer discount codes.
  * `f`, `h`, `t` — reserved; no effect at present.
* **stock**: nonnegative integer unit count.

Inputs containing products that mention other product types or promotion codes should result in an error. 

## Orders

Each `ORDER` block carries:

* `ITEM` records with fields `productId|qty`, `qty` a positive integer.
* Zero or more `DISCOUNT` records carrying one of the codes:
  * `UNI` — 10% off eligible items.
  * `HEALTH` — 20% off eligible items.
  * `PROMO` — recognised but currently inactive (treated as 0%).
  * `EMPLOYEE` — recognised but currently inactive (treated as 0%).

Inputs containing discount codes that are not listed above should result in an error.

## Acceptance

An order is **accepted** if for every item, the current stock of that product is at least the 
ordered quantity.

In addition, the client will provide a few further constraints on orders which you should check too.

Otherwise it is **rejected**. The inventory seen by each order reflects
all earlier accepted orders in the same run.

## Pricing

Pricing is computed against the current inventory regardless of whether
the order is accepted, so rejected orders still report an accurate price.

**NEW:** In addition to the `c` 3 for 2 code described in the warmup (and again below), the customer has
requested two additional promotional codes be activated with additional offer types: *category discounts*
and *buy N, get percentage discount*.

### Promotional 3‑for‑2

If the total number of ordered units whose product code contains `c` is
at least 3, exactly one unit is free.  That is, the order is discounted by the
minimum price of a `c`-coded item.  
Only one unit is ever made free by this rule, no matter how many
`c`‑flagged units the order contains.

### Product type discounts

The client will provide you with a code that indicates items of a specific product type having that code should be 
discounted by a provided percentage.  To calculate the discount, we multiply the cost of each affected 
items by the percentage, round up, and sum the results (as described in `GeneralRequirements.md`).

### Buy n items, get p% discount

The client will also provide you with a code such that all items having this code (independently of category) get 
a certain percentage discount, as long as at least some given number of items having that code are purchased.  (This 
applies even if only one **kind** of product is purchased, as long as at least 3 such items are purchased.)
This works just like the category discount code but without the category constraint.  Also, recall that 
when applying percentage discounts to multiple items, we apply the discount to each item individually and round up 
to the nearest pound.


## Inventory and balance updates

When an order is accepted, for each item in the order, subtract each item's `qty` from the corresponding product's 
`stock` and add the final price to the store balance. Rejected orders leave the inventory and balance unchanged.

## Output

As per the warmup documents. The output `DISCOUNT` record for an order, when present, carries exactly the chosen
pricing discount code. If no code was needed to get the lowest price, no `DISCOUNT` record appears on that order.

## Example

The running example in `ex01-input-format.md` is a canonical worked example for
WordWorld.  However, the example output shown for this input is not necessarily the correct one for your
assignment, because the correct results may depend on the discount percentages, acceptance rules, and pricing rules
specific to your assignment.
