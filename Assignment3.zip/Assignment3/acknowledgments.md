# Acknowledgments
I completed this assignment independently.

I used the Java standard library (such as TreeMap, TreeSet, and Scanner)
for data storage and input processing.